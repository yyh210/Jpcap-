import java.util.Scanner;
import jpcap.JpcapCaptor;
import jpcap.NetworkInterface;
import java.io.IOException;
import jpcap.PacketReceiver;
import jpcap.packet.*;
import tool.Convert;
import myPacket.*;
public class Capture {
	JpcapCaptor captor = null;
	int len = 1600;
	NetworkInterface[] devices = null;
	Packet p = null;
	
	public Capture(int dev_id,int cnt, String filter) {
		//Ethernet 2 ��·֡�� MTU 1500
		devices = JpcapCaptor.getDeviceList();
		try {
			captor = JpcapCaptor.openDevice(devices[dev_id], len, true, 1000);
			//��������������������ģʽ true ��������ģʽ
		}catch(IOException e) {
			e.printStackTrace();
		}
		try {
			captor.setFilter(filter, true);
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		MyPacketHandler handler = new MyPacketHandler();
		captor.loopPacket(cnt, handler);
	}

	public static void main(String args[]) {
		Scanner s = new Scanner(System.in);
		String[] key_in = null;
		boolean flag = false;
		String filter = "";
		
		while(flag == false) {
			if(s.hasNextLine()) {
				key_in = s.nextLine().split(" ");
				
			}
			if(key_in.length > 3||key_in.length < 2) {
				System.out.println("Illegal input");
			}else {
				if(key_in.length == 3) {
					filter = key_in[2];
				}
				flag = true;
			}
		}
		int dev_id = Integer.parseInt(key_in[0]);
		int cnt = Integer.parseInt(key_in[1]);
		s.close();
		new Capture(dev_id, cnt, filter);
	}
		
}


class MyPacketHandler implements PacketReceiver{
	public void receivePacket(Packet p) {
		System.out.println("****************START*********************");
		MyEthernetPacket epacket = new MyEthernetPacket(p);
		System.out.println(epacket+"\n"+"�����ֶΣ�"+epacket.type);//print mac address
		switch(epacket.type) {
		case "ip" :
			MyIPPacket ipacket = new MyIPPacket(p);
			System.out.println("\nIP head:");
			ipacket.display();
			switch(ipacket.protocol) {
			case "tcp":
				System.out.println("\nTCP head:");
				MyTCPPacket t = new MyTCPPacket(p);
				t.display();
				break;
			case "udp":
				System.out.println("\nUDP head:");
				MyUDPPacket u = new MyUDPPacket(p);
				u.display();
				break;
			default:
				System.out.println("\nThis is a/an "+ipacket.protocol+
						" packet but there is no more information ");
			}
			break;
		case "arp":
			MyARPPacket a =  new MyARPPacket(p);
			a.display();
			break;
		default:	
			System.out.println("\nThis is a/an "+epacket.type+
					" type but there is no more information ");
		}
		System.out.println("Data:\n"+Convert.bytesToHex(epacket.data));
		System.out.println("****************END***********************\n");
		
	}
	
	
}
