package myPacket;
import jpcap.packet.Packet;
import tool.Convert;
public class MyIPPacket extends MyEthernetPacket{
	public int version = 0;
	public int head_len = 0;
	public int total_len = 0;
	public int identification = 0;
	public int flag = 0;
	public int offset = 0;
	public int ttl = 0;
	public String protocol = null;
	public int[] src = new int[4];
	public int[] dst = new int[4];
	public String check_sum = null;

	
	public MyIPPacket(Packet p) {
		super(p);
		if( !type.equals("ip")) {
			System.out.println("This is not an IP packet");
			return;
			
		}
		//��ֹbyte���������ת��Ϊint
		
		
		
		version = head[14]/16;
		head_len = 4*(head[14]%16);
		total_len = con_head[16]*256 + con_head[17];
		identification = con_head[18]*256+con_head[19];
		flag = head[20]/32;
		offset = (con_head[20]%32)*256+con_head[21];
		ttl = con_head[22];
		switch(head[23]) {
		case 1:
			protocol = new String("icmp");
			break;
		case 2:
			protocol = new String("igmp");
			break;
		case 6:
			protocol = new String("tcp");
			break;
		case 17:
			protocol = new String("udp");
			break;
		default:
				break;
				
		}
		
		check_sum = new String(Convert.bytesToHex(head[24])+
				Convert.bytesToHex(head[25]));
		
		for(int i=0; i<4;i++) {
			src[i] = con_head[26+i];
			dst[i] = con_head[30+i];
		}
		
		
		
	}
	public String getAddress() {
		String s ="ԴIP:";
		String d ="Ŀ��IP:";
		s = s+ src[0]+":"+src[1]+":"+src[2]+":"+src[3];
		d = d+ dst[0]+":"+dst[1]+":"+dst[2]+":"+dst[3];
		return s+"\n"+d;
	}
	@Override
	public String toString() {
		return getAddress();
	}
	public void display() {
		String res = "";
		res += "�汾��"+version+"\n"+
				"Э��:"+protocol+"\n"+
				"�ײ�����:"+head_len+" Byte"+"\n"+
				"�ܳ���:"+total_len+" Byte"+"\n"+
				"��ʶ:"+identification+"\n"+
				"��־:"+flag+"\n"+
				"Ƭλ��:"+offset+"\n"+
				"����ʱ��:"+ttl;
		System.out.println(res);
		System.out.println(getAddress());
	}
	
}
