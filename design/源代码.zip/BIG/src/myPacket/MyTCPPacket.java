package myPacket;
import jpcap.packet.Packet;
import tool.Convert;
public class MyTCPPacket extends MyIPPacket {
	public int src_port = 0;
	public int dst_port = 0;
	public long seq_num = 0;
	public long ack_num = 0;
	public int  tcp_head_len=0;
	public int urg = 0;
	public int ack = 0;
	public int psh = 0;
	public int rst = 0;
	public int syn = 0;
	public int fin = 0;
	public int win_size = 0;
	public String tcp_check_sum = null;
	public int urgent_pointer = 0;
	public int[] options = new int[12];
	
	
	public MyTCPPacket(Packet p) {
		super(p);
		if(!this.protocol.equals("tcp")) {
			System.out.println("This is not a tcp packet");
			return;
		}
		src_port = con_head[34]*256 +
				con_head[35];
		dst_port = con_head[36]*256 +
				con_head[37];
		seq_num = con_head[38]*16777216+con_head[39]*65536+
				con_head[40]*256+con_head[41];
		ack_num = con_head[42]*16777216+con_head[43]*65536+
				con_head[44]*256+con_head[45];//ack_flag==1 ��Ч
		tcp_head_len = (con_head[46]/16)*4;
		int[] res = Convert.intToBin(con_head[47]);
		urg = res[2];
		ack = res[3];
		psh = res[4];
		rst = res[5];
		syn = res[6];
		fin = res[7];
		win_size = con_head[48]*256+con_head[49];
		tcp_check_sum = Convert.bytesToHex(con_head[50])+Convert.bytesToHex(con_head[51]);
		urgent_pointer = con_head[52]*256 + con_head[53];
		for(int i = 0;i<12;i++) {
			options[i] = con_head[54+i];
		}
	}
	@Override
	public String toString() {
		return "Port:"+src_port+"-->"+dst_port;
	}
	
	@Override
	public void display() {
		String res = "";
		res +="Դ�˿ڣ� "+src_port+"\n"+
				"Ŀ�Ķ˿ڣ� "+dst_port+"\n"+
				"��ţ� " + seq_num+"\n"+
				"ȷ�Ϻţ�" + ack_num+"\n"+
				"����ƫ�ƣ�"+tcp_head_len+" Byte"+"\n"+
				"6����־λ��" +urg+","+ack+","+psh+","+rst+","+syn+","+fin+"\n"+
				"���ڣ�"+win_size+" Byte"+"\n"+
				"TCPУ��ͣ�" + tcp_check_sum+"\n"+
				"����ָ�룺" + urgent_pointer;
		System.out.println(res);
	}
}
