package myPacket;
import jpcap.packet.Packet;
import tool.Convert;
public class MyEthernetPacket{
	public int[] dst_mac = new int[6];
	public int[] src_mac = new int[6];
	public String type = null;
	public byte[] data = null;
	public byte[] head = null;
	protected int[] con_head=new int[100];
	
	
	public MyEthernetPacket(Packet p) {
		head = p.header;
		data = p.data;
		
		for(int i= 0;i<head.length;i++ ) {
			con_head[i] = Convert.regular(head[i]);
		}
		
		int type_int = head[12]*256+head[13];
		for(int i=0;i<6;i++) {
			dst_mac[i] = con_head[i];
			src_mac[i] = con_head[i+6];
		}
		
		switch(type_int) {
		case 2054:
			type = new String("arp");
			break;
		case 2048:
			type = new String("ip");
			break;
		case 262197:
			type = new String("rarp");
			break;
		default:
			type = new String("UNKNOWN");
			break;
		}
		
	}
	@Override
	public String toString() {
		String src = "";
		String dst = "";
		for(int i =0;i<6;i++) {
			src += Convert.bytesToHex(src_mac[i])+":";
			dst += Convert.bytesToHex(dst_mac[i])+":";
		}
		src = src.substring(0, src.length()-1);
		dst = dst.substring(0, dst.length()-1);
		
		return "MAC:"+src+"-->"+dst;
	}
}
