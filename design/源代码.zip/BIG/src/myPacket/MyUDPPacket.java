package myPacket;
import jpcap.packet.Packet;
import tool.Convert;
public class MyUDPPacket extends MyIPPacket{
	public int src_port = 0;
	public int dst_port = 0;
	public int udp_len = 0;
	public String udp_check_sum = null;

	public  MyUDPPacket(Packet p) {
		super(p);
		if(!this.protocol.equals("udp")) {
			System.out.println("This is not a udp packet");
			return;
		}
		src_port = con_head[34]*256 +
				con_head[35];
		dst_port = con_head[36]*256 +
				con_head[37];
		udp_len = con_head[38]*256 +
				con_head[39];
		udp_check_sum = Convert.bytesToHex(con_head[40])+
				Convert.bytesToHex(con_head[41]);
	}
	@Override
	public String toString() {
		return "Port:"+src_port+"-->"+dst_port;
	}
	@Override
	public void display() {
		String res = "";
		res +="Դ�˿ڣ� "+src_port+"\n"+
				"Ŀ�Ķ˿ڣ� "+dst_port+"\n"+
				"upd���ȣ�"+udp_len+" Byte"+"\n"+
				"udpУ��ͣ�"+udp_check_sum+"\n";
		System.out.println(res);
	}
}
