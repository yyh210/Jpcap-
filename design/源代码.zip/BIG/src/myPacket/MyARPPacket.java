package myPacket;
import jpcap.packet.Packet;
import tool.Convert;
public class MyARPPacket extends MyEthernetPacket{
	public int hardware_type = 0;
	public String upper_protocol = null;
	public int mac_len = 0;
	public int ip_len = 0;
	public int op_type = 0;
	public int[] src_ip = new int[20];
	public int[] dst_ip = new int[20];
	public int[] arp_src_mac = new int[6];
	public int[] arp_dst_mac = new int[6];
	
	
	public MyARPPacket(Packet p) {
		super(p);
		hardware_type = con_head[14]*256 + con_head[15];
		switch(Convert.bytesToHex(con_head[16])+
				Convert.bytesToHex(con_head[17])) {
		
		case "0800":
			upper_protocol = "ipv4";
			break;
		case "0806":
			upper_protocol = "ipv6";
			break;
		default:
			upper_protocol = "UNKNOWN";
		}
		mac_len = con_head[18];
		ip_len = con_head[19];
		op_type = con_head[20]*256 + con_head[21];
		for(int i=0;i<4;i++) {
			src_ip[i] = con_head[28+i];
			dst_ip[i] = con_head[38+i];
		}
		for(int i=0;i<6;i++) {
			arp_src_mac[i] = con_head[22+i];
			arp_dst_mac[i] = con_head[32+i];
		}
	}
	
	public void display() {
		String s = "";
		String src = "";
		String dst = "";
		for(int i =0;i<6;i++) {
			src += Convert.bytesToHex(arp_src_mac[i])+":";
			dst += Convert.bytesToHex(arp_dst_mac[i])+":";
		}
		src = src.substring(0, src.length()-1);
		dst = dst.substring(0, dst.length()-1);
		
		s += "Ӳ�����ͣ�"+hardware_type+"\n"+
				"�ϲ�Э�飺"+upper_protocol+"\n"+
				"MAC��ַ���ȣ�"+mac_len+" Byte"+"\n"+
				"IP��ַ���ȣ�"+ip_len+" Byte"+"\n"+
				"�������ͣ�"+ op_type+ "\n"+
				"ԴMAC��ַ��"+src+"\n"+
				"ԴIP��ַ��"+src_ip[0]+":"+src_ip[1]+":"+src_ip[2]+":"+src_ip[3]+"\n"+
				"Ŀ��MAC��ַ��"+dst+"\n"+
				"Ŀ��IP��ַ��"+dst_ip[0]+":"+dst_ip[1]+":"+dst_ip[2]+":"+dst_ip[3];
		System.out.println(s);
	}
}
