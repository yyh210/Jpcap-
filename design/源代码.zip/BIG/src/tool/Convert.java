package tool;

public class Convert {
	
	public static String bytesToHex(int... bytes) {  
	    StringBuffer sb = new StringBuffer();  
	    for(int i = 0; i < bytes.length; i++) {  
	        String hex = Integer.toHexString(bytes[i] & 0xFF);  
	        if(hex.length() < 2){  
	            sb.append(0);  
	        }  
	        sb.append(hex);  
	    }  
	    return sb.toString();  
	} 
	public static String bytesToHex(byte... bytes) {  
	    StringBuffer sb = new StringBuffer();  
	    for(int i = 0; i < bytes.length; i++) {  
	        String hex = Integer.toHexString(bytes[i] & 0xFF);  
	        if(hex.length() < 2){  
	            sb.append(0);  
	        }  
	        sb.append(hex);  
	    }  
	    return sb.toString();  
	} 
	
	public static int regular(byte b) {
		//ת��Ϊ256�µ�ģϵͳ
		int res = 0;
		res = (256 + b)%256;
		return res;
	}
	public static int[] intToBin(int b) {
		int[] res = new int[8];
		res[0] = (b>>7) & 0x1;
		res[1] = (b>>6) & 0x1;
		res[2] = (b>>5) & 0x1;
		res[3] = (b>>4) & 0x1;
		res[4] = (b>>3) & 0x1;
		res[5] = (b>>2) & 0x1;
		res[6] = (b>>1) & 0x1;
		res[7] = (b) & 0x1;
		return res;
	}
	
}
